"""
Example demonstrating the ReactpyForms component.

This example shows how to use the ReactpyForms component with click event handling.
Run with: python -m examples.button_example
"""
from typing import Dict, Any
from reactpy import component, html, use_state
from reactpy_forms import ReactpyForms

from utils.app_runner import AppRunner


@component
def ButtonDemo():
    """Demonstration of the ReactpyForms component with various configurations."""
    click_count, set_click_count = use_state(0)
    last_message, set_last_message = use_state("No button clicked yet")

    def handle_simple_click(event: Dict[str, Any]) -> None:
        """Handle clicks from the simple button."""
        set_click_count(click_count + 1)
        set_last_message("Simple button clicked!")

    def handle_custom_click(event: Dict[str, Any]) -> None:
        """Handle clicks from the button with custom event data."""
        set_click_count(click_count + 1)
        data: Dict[str, Any] = event.get("data", {})
        message: str = data.get("message", "No message")
        set_last_message(f"Custom button clicked! Data: {message}")

    def handle_styled_click(event: Dict[str, Any]) -> None:
        """Handle clicks from the styled button."""
        set_click_count(click_count + 1)
        set_last_message("Styled button clicked!")

    return html.div(
        html.h1("ReactpyForms Component Examples"),
        html.div(
            {"style": {"margin": "20px 0", "padding": "20px", "background": "#f0f0f0"}},
            html.h2("Click Statistics"),
            html.p(f"Total clicks: {click_count}"),
            html.p(f"Last action: {last_message}"),
        ),
        html.div(
            {"style": {"margin": "20px 0"}},
            html.h3("1. Simple Button (default text)"),
            ReactpyForms(on_click=handle_simple_click),
        ),
        html.div(
            {"style": {"margin": "20px 0"}},
            html.h3("2. Button with Custom Text"),
            ReactpyForms(
                text="Click me!",
                on_click=handle_simple_click,
            ),
        ),
        html.div(
            {"style": {"margin": "20px 0"}},
            html.h3("3. Button with Event Data"),
            ReactpyForms(
                text="Button with Data",
                on_click=handle_custom_click,
                event_data={"message": "Hello from button!"},
            ),
        ),
        html.div(
            {"style": {"margin": "20px 0"}},
            html.h3("4. Styled Button (using kwargs)"),
            ReactpyForms(
                text="Styled Button",
                on_click=handle_styled_click,
                style={
                    "background": "#4CAF50",
                    "color": "white",
                    "padding": "15px 32px",
                    "fontSize": "16px",
                    "border": "none",
                    "borderRadius": "4px",
                    "cursor": "pointer",
                },
            ),
        ),
        html.div(
            {"style": {"margin": "20px 0"}},
            html.h3("5. Button without Click Handler"),
            html.p("This button doesn't do anything when clicked:"),
            ReactpyForms(text="I'm just here"),
        ),
    )


@component
def AppMain():
    """Main application component."""
    return html.div(
        {"style": {"maxWidth": "800px", "margin": "0 auto", "padding": "20px"}},
        ButtonDemo()
    )

# python -m examples.button_example

if __name__ == "__main__":
    AppRunner.run(AppMain, title="ReactpyForms Component Example")
